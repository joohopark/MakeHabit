//
//  PromissListCell.swift
//  HabitPromiss
//
//  Created by 배지호 on 2018. 5. 28..
//  Copyright © 2018년 주호박. All rights reserved.
//

import UIKit
import FSCalendar
class PromissListCell: UITableViewCell {
  
  @IBOutlet weak var promissListText: UILabel!
  
  
  override func awakeFromNib() {
    super.awakeFromNib()
    
  }
}
