//
//  IconCategoryHeaderView.swift
//  HabitPromiss
//
//  Created by 주호박 on 2018. 6. 3..
//  Copyright © 2018년 주호박. All rights reserved.
//

import UIKit

class IconCategoryHeaderView: UICollectionReusableView {

    @IBOutlet weak var headerImgae: UIImageView!
    @IBOutlet weak var headerName: UILabel!
    
}
